---
name: New App Idea
about: Log a new Micro-SaaS idea to research
title: '[IDEA] '
labels: idea
---

## 💡 App Idea

## 🎯 Target Customer

## 💰 Revenue Potential
- Monthly Revenue (similar apps): 
- Starting Cost Estimate: 
- Effort Level: Easy / Medium / Hard

## ✅ Validation Steps
- [ ] Posted in relevant community
- [ ] Got 5+ positive responses
- [ ] Found 3 willing beta users

## 🛠️ Tech Stack Ideas

## 📝 Notes
